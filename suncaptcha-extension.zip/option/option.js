document.addEventListener('DOMContentLoaded', function () {
  // Config state
  let config = {};

  // Default Configuration values (matching config.js)
  const default_config = {
    clientKey: 'sk_8178720677924fb499b8bb86',
    host: 'https://suncaptcha.com/api/v1/',
    autorun: true,
    imageclassification: true,
    hcaptcha: true,
    imagetotext: true,
    rainbow: true,
    times: 200,
    isTextCaptcha: false,
    endTimes: '20',
    isAutoClickCheckBox: true,
    checkBoxClickDelayTime: "500",
    isOpenEndTimes: true,
    isOpenCloudflare: false,
    isOpenCloudflareTurnstileProtocol: false,
    isAutoSubmit: true,
    autoSubmitDelayTime: 100,
    autoSubmitDelayFloatRate: 0.1,
    workStatusFlag: '',
    jsControlObjectName: 'sunCaptcha',
    allowJsInject: false,
    network: {
      hcaptchaVerifyFailDelay: 1000,
      hcaptchaVerifyTry: 3,
      recaptchaVerifyFailDelay: 1000,
      recaptchaVerifyTry: 2,
      funcaptchaVerifyFailDelay: 1000,
      funcaptchaVerifyTry: 3
    },
    hcaptchaConfig: {
      isPassDragChallenge: false,
      isAutoRefresh: true,
      isSwitchToEnglishContent: false,
      isPassMoveCanvasChallenge: false,
      canvasRecordDuration: 6000
    },
    funcaptchaConfig: {
      isOpen: true,
      actionAfterRecSuccess: "nothing",
      actionAfterOneRecFail: "restart",
      actionAfterRecFail: "tryAgain",
      actionDelay: 3000,
      isAutoClickPrePage: true
    },
    recaptchaConfig: {
      isOpen: true,
      isUseNewScript: true,
      delayFor1X1: 3000,
      isAdaptInvisible: false,
      isOpenProtocol: false,
      V3TaskType: 'RecaptchaV3TaskProxylessM1S7',
      V2TaskType: 'RecaptchaV2TaskProxyless'
    },
    textCaptchaConfig: {
      isTransToUppercase: false,
      taskType: 'ImageToTextTaskTest'
    },
    blackListConfig: {
      isOpen: false,
      urlList: []
    },
    whiteListConfig: {
      isOpen: false,
      urlList: []
    },
    awsCaptchaConfig: {
      isOpen: true
    },
    isHideKey: false
  };

  // Elements
  const tabMenuItems = document.querySelectorAll('.menu-item');
  const tabPanels = document.querySelectorAll('.tab-panel');
  const settingsForm = document.getElementById('settings-form');
  const btnReset = document.getElementById('btn-reset');
  const toast = document.getElementById('toast');

  // Input Elements
  const optClientKey = document.getElementById('opt-client-key');
  const optHost = document.getElementById('opt-host');
  const optTimes = document.getElementById('opt-times');
  const optOpenLimit = document.getElementById('opt-open-limit');
  const optLimitTimes = document.getElementById('opt-limit-times');
  const optAutoSubmit = document.getElementById('opt-auto-submit');
  const optSubmitDelay = document.getElementById('opt-submit-delay');
  const optSubmitFloat = document.getElementById('opt-submit-float');
  const optAutoCheckbox = document.getElementById('opt-auto-checkbox');
  const optCheckboxDelay = document.getElementById('opt-checkbox-delay');
  
  const optFcOpen = document.getElementById('opt-fc-open');
  const optFcFailOne = document.getElementById('opt-fc-fail-one');
  const optFcFailAll = document.getElementById('opt-fc-fail-all');
  const optFcAutoStart = document.getElementById('opt-fc-auto-start');

  const optHcOpen = document.getElementById('opt-hc-open');
  const optHcRefresh = document.getElementById('opt-hc-refresh');
  const optHcEnglish = document.getElementById('opt-hc-english');
  const optHcSkipCanvas = document.getElementById('opt-hc-skip-canvas');

  const optRcOpen = document.getElementById('opt-rc-open');
  const optRcV2Type = document.getElementById('opt-rc-v2-type');
  const optRcFadeDelay = document.getElementById('opt-rc-fade-delay');
  const optRcInvisible = document.getElementById('opt-rc-invisible');
  const optRcV3Protocol = document.getElementById('opt-rc-v3-protocol');
  const optRcV3Type = document.getElementById('opt-rc-v3-type');
  
  const optCfOpen = document.getElementById('opt-cf-open');

  const optWlOpen = document.getElementById('opt-wl-open');
  const optWlList = document.getElementById('opt-wl-list');
  
  const optBlOpen = document.getElementById('opt-bl-open');
  const optBlList = document.getElementById('opt-bl-list');

  // Group Containers (for conditional showing)
  const groupSubmitDelay = document.getElementById('group-submit-delay');
  const groupCheckboxDelay = document.getElementById('group-checkbox-delay');
  const groupV3TaskType = document.getElementById('group-v3-task-type');
  const groupWhitelist = document.getElementById('group-whitelist');
  const groupBlacklist = document.getElementById('group-blacklist');

  // 1. TAB SWITCHING
  tabMenuItems.forEach(item => {
    item.addEventListener('click', function () {
      tabMenuItems.forEach(i => i.classList.remove('active'));
      tabPanels.forEach(p => p.classList.remove('active'));

      item.classList.add('active');
      const tabId = item.getAttribute('data-tab');
      document.getElementById(tabId).classList.add('active');
    });
  });

  // 2. LOAD CONFIG
  chrome.storage.local.get(['config'], function (result) {
    if (result.config) {
      config = result.config;
    } else {
      config = JSON.parse(JSON.stringify(default_config));
    }
    initUI();
  });

  // Populate inputs from configuration object
  function initUI() {
    optClientKey.value = config.clientKey || '';
    optHost.value = config.host || '';
    optTimes.value = config.times || 200;
    
    optOpenLimit.checked = !!config.isOpenEndTimes;
    optLimitTimes.value = config.endTimes || '20';

    optAutoSubmit.checked = !!config.isAutoSubmit;
    optSubmitDelay.value = config.autoSubmitDelayTime || 100;
    optSubmitFloat.value = config.autoSubmitDelayFloatRate || 0.1;

    optAutoCheckbox.checked = !!config.isAutoClickCheckBox;
    optCheckboxDelay.value = config.checkBoxClickDelayTime || 500;

    // FunCaptcha
    if (!config.funcaptchaConfig) config.funcaptchaConfig = {};
    optFcOpen.checked = !!config.funcaptchaConfig.isOpen;
    optFcFailOne.value = config.funcaptchaConfig.actionAfterOneRecFail || 'restart';
    optFcFailAll.value = config.funcaptchaConfig.actionAfterRecFail || 'tryAgain';
    optFcAutoStart.checked = !!config.funcaptchaConfig.isAutoClickPrePage;

    // hCaptcha
    if (!config.hcaptchaConfig) config.hcaptchaConfig = {};
    optHcOpen.checked = !!config.hcaptcha;
    optHcRefresh.checked = !!config.hcaptchaConfig.isAutoRefresh;
    optHcEnglish.checked = !!config.hcaptchaConfig.isSwitchToEnglishContent;
    optHcSkipCanvas.checked = !!config.hcaptchaConfig.isPassMoveCanvasChallenge;

    // reCaptcha / Turnstile
    if (!config.recaptchaConfig) config.recaptchaConfig = {};
    optRcOpen.checked = !!config.imageclassification;
    optRcV2Type.value = config.recaptchaConfig.V2TaskType || 'RecaptchaV2TaskProxyless';
    optRcFadeDelay.value = config.recaptchaConfig.delayFor1X1 || 3000;
    optRcInvisible.checked = !!config.recaptchaConfig.isAdaptInvisible;
    optRcV3Protocol.checked = !!config.recaptchaConfig.isOpenProtocol;
    optRcV3Type.value = config.recaptchaConfig.V3TaskType || 'RecaptchaV3TaskProxylessM1S7';
    
    optCfOpen.checked = !!config.isOpenCloudflareTurnstileProtocol;

    // Whitelist & Blacklist
    if (!config.whiteListConfig) config.whiteListConfig = {};
    optWlOpen.checked = !!config.whiteListConfig.isOpen;
    optWlList.value = (config.whiteListConfig.urlList || []).join('\n');

    if (!config.blackListConfig) config.blackListConfig = {};
    optBlOpen.checked = !!config.blackListConfig.isOpen;
    optBlList.value = (config.blackListConfig.urlList || []).join('\n');

    // Trigger toggle visibilities
    updateConditionalVisibilities();
  }

  // Handle conditional forms hiding
  function updateConditionalVisibilities() {
    groupSubmitDelay.style.display = optAutoSubmit.checked ? 'flex' : 'none';
    groupCheckboxDelay.style.display = optAutoCheckbox.checked ? 'flex' : 'none';
    groupV3TaskType.style.display = optRcV3Protocol.checked ? 'block' : 'none';
    groupWhitelist.style.display = optWlOpen.checked ? 'block' : 'none';
    groupBlacklist.style.display = optBlOpen.checked ? 'block' : 'none';
  }

  // Listeners for conditional inputs
  optAutoSubmit.addEventListener('change', updateConditionalVisibilities);
  optAutoCheckbox.addEventListener('change', updateConditionalVisibilities);
  optRcV3Protocol.addEventListener('change', updateConditionalVisibilities);
  optWlOpen.addEventListener('change', updateConditionalVisibilities);
  optBlOpen.addEventListener('change', updateConditionalVisibilities);

  // 3. SAVE CONFIG
  settingsForm.addEventListener('submit', function (e) {
    e.preventDefault();

    // Map inputs to config object
    config.clientKey = optClientKey.value.trim();
    config.host = optHost.value.trim();
    config.times = parseInt(optTimes.value, 10) || 200;
    config.isOpenEndTimes = optOpenLimit.checked;
    config.endTimes = optLimitTimes.value.toString();

    config.isAutoSubmit = optAutoSubmit.checked;
    config.autoSubmitDelayTime = parseInt(optSubmitDelay.value, 10) || 100;
    config.autoSubmitDelayFloatRate = parseFloat(optSubmitFloat.value) || 0.1;

    config.isAutoClickCheckBox = optAutoCheckbox.checked;
    config.checkBoxClickDelayTime = optCheckboxDelay.value.toString();

    // FunCaptcha
    config.funcaptchaConfig.isOpen = optFcOpen.checked;
    config.funcaptchaConfig.actionAfterOneRecFail = optFcFailOne.value;
    config.funcaptchaConfig.actionAfterRecFail = optFcFailAll.value;
    config.funcaptchaConfig.isAutoClickPrePage = optFcAutoStart.checked;

    // hCaptcha
    config.hcaptcha = optHcOpen.checked;
    config.hcaptchaConfig.isAutoRefresh = optHcRefresh.checked;
    config.hcaptchaConfig.isSwitchToEnglishContent = optHcEnglish.checked;
    config.hcaptchaConfig.isPassMoveCanvasChallenge = optHcSkipCanvas.checked;

    // reCaptcha
    config.imageclassification = optRcOpen.checked;
    config.recaptchaConfig.V2TaskType = optRcV2Type.value;
    config.recaptchaConfig.delayFor1X1 = parseInt(optRcFadeDelay.value, 10) || 3000;
    config.recaptchaConfig.isAdaptInvisible = optRcInvisible.checked;
    config.recaptchaConfig.isOpenProtocol = optRcV3Protocol.checked;
    config.recaptchaConfig.V3TaskType = optRcV3Type.value;

    config.isOpenCloudflareTurnstileProtocol = optCfOpen.checked;

    // Whitelist
    config.whiteListConfig.isOpen = optWlOpen.checked;
    config.whiteListConfig.urlList = optWlList.value.split('\n')
      .map(item => item.trim())
      .filter(item => item.length > 0);

    // Blacklist
    config.blackListConfig.isOpen = optBlOpen.checked;
    config.blackListConfig.urlList = optBlList.value.split('\n')
      .map(item => item.trim())
      .filter(item => item.length > 0);

    // Save to storage
    chrome.storage.local.set({ config }, function () {
      showToast('Settings saved successfully!');
    });
  });

  // Show dynamic toast banner
  function showToast(message) {
    toast.querySelector('.toast-message').textContent = message;
    toast.classList.add('show');
    setTimeout(() => {
      toast.classList.remove('show');
    }, 3000);
  }

  // 4. RESET TO DEFAULTS
  btnReset.addEventListener('click', function () {
    if (confirm('Are you sure you want to restore all settings to default values?')) {
      config = JSON.parse(JSON.stringify(default_config));
      chrome.storage.local.set({ config }, function () {
        initUI();
        showToast('Settings reset to default values!');
      });
    }
  });
});
